-- =============================================
-- SCRIPT COMPLETO BASE DE DATOS GESTOR VIDEOJUEGOS
-- =============================================

-- Borrar tablas si existen para empezar limpio
DROP TABLE IF EXISTS amigos;
DROP TABLE IF EXISTS coleccion_usuario;
DROP TABLE IF EXISTS valoraciones;
DROP TABLE IF EXISTS videojuegos;
DROP TABLE IF EXISTS usuarios;

-- =============================================
-- TABLAS
-- =============================================

-- Usuarios
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

-- Videojuegos
CREATE TABLE videojuegos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(100) NOT NULL,
    plataforma VARCHAR(50) NOT NULL,
    genero VARCHAR(50),
    descripcion TEXT
);

-- Colección de usuario
CREATE TABLE coleccion_usuario (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    videojuego_id INT NOT NULL,
    estado ENUM('jugando','completado') DEFAULT 'jugando',
    UNIQUE (usuario_id, videojuego_id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (videojuego_id) REFERENCES videojuegos(id) ON DELETE CASCADE
);

-- Valoraciones
CREATE TABLE valoraciones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    videojuego_id INT NOT NULL,
    puntuacion INT NOT NULL,
    UNIQUE (usuario_id, videojuego_id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (videojuego_id) REFERENCES videojuegos(id) ON DELETE CASCADE
);

-- Amigos
CREATE TABLE amigos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    amigo_id INT NOT NULL,
    estado ENUM('pendiente', 'aceptado') DEFAULT 'pendiente',
    UNIQUE (usuario_id, amigo_id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (amigo_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- =============================================
-- POBLADO
-- =============================================

-- Videojuegos
INSERT INTO videojuegos (titulo, plataforma, genero, descripcion) VALUES
('Cyberpunk 2077', 'PC', 'RPG', 'Juego de rol futurista con mundo abierto'),
('Horizon Zero Dawn', 'PS4', 'Aventura', 'Exploración y combate contra máquinas'),
('Super Mario Odyssey', 'Switch', 'Plataforma', 'Aventuras por distintos mundos'),
('Halo Infinite', 'Xbox', 'FPS', 'Shooter en primera persona con campaña y multijugador'),
('FIFA 23', 'PC', 'Deportes', 'Simulador de fútbol realista'),
('Forza Horizon 5', 'Xbox', 'Carreras', 'Juego de carreras en mundo abierto'),
('Animal Crossing', 'Switch', 'Simulación', 'Simulación de vida en una isla'),
('Resident Evil Village', 'PC', 'Horror', 'Survival horror en primera persona'),
('Ghost of Tsushima', 'PS5', 'Acción', 'Juego de samuráis en mundo abierto'),
('Call of Duty: Modern Warfare', 'PC', 'FPS', 'Shooter militar competitivo'),
('Minecraft', 'PC', 'Sandbox', 'Construcción y supervivencia en mundo abierto'),
('League of Legends', 'PC', 'MOBA', 'Juego de estrategia y equipo competitivo'),
('Overwatch 2', 'PC', 'FPS', 'Shooter de equipos con héroes únicos'),
('The Last of Us Part II', 'PS4', 'Aventura', 'Historia post-apocalíptica con sigilo'),
('Pokémon Scarlet', 'Switch', 'RPG', 'Aventura por el mundo Pokémon'),
('Valorant', 'PC', 'FPS', 'Shooter táctico por equipos'),
('Elder Scrolls Online', 'PC', 'MMORPG', 'Juego online de rol masivo'),
('Among Us', 'PC', 'Party', 'Juego de deducción social'),
('Dead Cells', 'PC', 'Rogue-like', 'Aventura con acción y permadeath'),
('Stardew Valley', 'PC', 'Simulación', 'Simulación de granja y vida en el pueblo');

-- Videojuegos extra
INSERT INTO videojuegos (titulo, plataforma, genero, descripcion) VALUES
('Hollow Knight', 'PC', 'Metroidvania', 'Aventura y exploración en un mundo subterráneo'),
('Celeste', 'PC', 'Plataforma', 'Supera desafíos y plataformas mientras escalas la montaña'),
('Dark Souls III', 'PS4', 'RPG', 'Reto, exploración y combate en un mundo oscuro'),
('Sekiro: Shadows Die Twice', 'PC', 'Acción', 'Combate samurái desafiante y sigilo'),
('The Legend of Zelda: Link''s Awakening', 'Switch', 'Aventura', 'Remake del clásico de Game Boy'),
('Super Smash Bros. Ultimate', 'Switch', 'Lucha', 'Combate con personajes de Nintendo y otros universos'),
('Genshin Impact', 'PC', 'RPG', 'Exploración y combate en un mundo abierto con gacha'),
('Resident Evil 4 Remake', 'PC', 'Horror', 'Remake de survival horror clásico con mejoras gráficas'),
('God of War Ragnarök', 'PS5', 'Acción', 'Mitología nórdica y combate épico'),
('Dragon Age: Inquisition', 'PC', 'RPG', 'Toma decisiones y gestiona un grupo de héroes'),
('FIFA 24', 'PS5', 'Deportes', 'Simulador de fútbol actualizado con nuevas mecánicas'),
('Mario Kart 8 Deluxe', 'Switch', 'Carreras', 'Carreras de karts con personajes y pistas de Mario'),
('The Sims 4', 'PC', 'Simulación', 'Crea y controla la vida de tus sims'),
('Fortnite', 'PC', 'Battle Royale', 'Juego multijugador de construcción y supervivencia'),
('Bloodborne', 'PS4', 'RPG', 'Explora Yharnam y enfrenta criaturas terroríficas'),
('Overcooked! 2', 'Switch', 'Party', 'Juego cooperativo de cocina caótica'),
('Terraria', 'PC', 'Sandbox', 'Exploración, construcción y aventura en 2D'),
('Final Fantasy VII Remake', 'PS5', 'RPG', 'Remake con gráficos modernos del clásico JRPG'),
('Cuphead', 'PC', 'Plataforma', 'Juego de acción con estilo cartoon y dificultad elevada'),
('Metroid Dread', 'Switch', 'Metroidvania', 'Exploración y combate con Samus en un planeta alienígena');

-- =============================================
-- NOTA
-- Las tablas coleccion_usuario, valoraciones y amigos se irán llenando a medida que los usuarios utilicen la aplicación.
-- =============================================